1- Install csaudiointcsof.1.0.4-installer.exe

2- Do bcdedit /set testsigning on | Restart

3- Use linux live replace csaudiointcsof.sys in C:/Windows/System32/drivers/csaudiointcsof.sys

4- Use UWD remove test mode watermarks

Thank to mainsilent
